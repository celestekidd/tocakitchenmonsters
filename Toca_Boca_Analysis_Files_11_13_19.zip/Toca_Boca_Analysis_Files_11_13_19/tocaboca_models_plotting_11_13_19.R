# Toca Boca Plots
# Celeste Kidd & Maddie Pelz
# last edited Nov 5 2019

library(Hmisc)
##install.packages("ggplot2") 
library(ggplot2)
#library(lme4)
library(lmerTest)
library(car)

# # Start loop to process data file
# 
# # Read in list of datafiles
# datafiles <- list.files(path = "data", full.names = TRUE, ignore.case = FALSE)
# 
# # Create obj for data, d
# d <- NULL
# 
# # For-loop to read in data 
# for (i in datafiles) {
# 	print(i)
# 	j <- read.table(i, header=TRUE, sep=",") 
# 	j$file <- i
# 	d <- rbind(d, j)
# }

d <- read.csv('mergedSummary.csv')

# Convert AgeMo to AgeYr
d$AgeYr <- d$AgeMo/12

d$DiscPerTouch <- d$UniqueTouches/d$TotalTouches

# Add a column for rounded age
d$AgeYrRd <- round(d$AgeYr)
  
# Add a column for size/total touches
d <- transform(d, SizeByTotalTouches = Size / TotalTouches)

# Make SubjID categorical
d$SubjID <- as.factor(d$SubjID)

# Make AgeYrRd categorical
d$AgeYrRd <- as.factor(d$AgeYrRd)

# Linear regression analyses


# Discovery Rate
DiscRateByAge <- glm(DiscRate ~ AgeYr, data=d)
summary(DiscRateByAge)
DiscRateByExp <- glm(DiscRate ~ Experience, data=d)
DiscRateByAgeAndExperience <- glm(DiscRate ~ AgeYr + Experience, data=d)
summary(DiscRateByAgeAndExperience)

# Discoveries per touch
DiscPerTouchByAge <- glm(DiscPerTouch ~ AgeYr, data=d)
summary(DiscPerTouchByAge)
DiscPerTouchByExp <- glm(DiscPerTouch ~ Experience, data=d)
DiscPerTouchByAgeAndExperience <- glm(DiscPerTouch ~ AgeYr + Experience, data=d)
summary(DiscPerTouchByAgeAndExperience)

# Touch Rate
TouchRateByAge <- glm(TouchRate ~ AgeYr, data=d)
summary(TouchRateByAge)
TouchRateByExp <- glm(TouchRate ~ Experience, data=d)
TouchRateByAgeAndExperience <- glm(TouchRate ~ AgeYr + Experience, data=d)
summary(TouchRateByAgeAndExperience)

# Static touches
StaticByAge <- glm(StaticRatio ~ AgeYr, data=d)
StaticByExperience <- glm(StaticRatio ~ Experience, data=d)
StaticByAgeAndExperience <- glm(StaticRatio ~ AgeYr + Experience, data=d)

# Zip analysis
PureSizeByAge <- glm(Size ~ AgeYr, data=d)
summary(PureSizeByAge)
PureSizeByAgeAndTotalTouches <- glm(Size ~ AgeYr + TotalTouches, data=d)
summary(PureSizeByAgeAndTotalTouches)
PureSizeByTotalTouches <- glm(Size ~ TotalTouches, data = d)
PureSizeByTotalTouches.Residuals = resid(PureSizeByTotalTouches)



# Plotting 

# Static ratio by age
staticage <- ggplot(d, aes(x = AgeYr, y = StaticRatio))+ 
  xlab ("Age (Years)")+
  ylab ("Proportion of Static Touches") +
  geom_point()+
  geom_smooth(method=lm)+
  theme_bw(base_size = 18)
staticage
ggsave(staticage, filename="StaticByAge.png", width = 8, height = 8)

# Static ratio by experience
staticexperience <- ggplot(d, aes(x = Experience, y = StaticRatio))+ 
  xlab ("Experience")+
  ylab ("Proportion of Static Touches")+
  geom_point()+
  geom_smooth(method=lm)+
  theme_bw()
staticexperience
ggsave(staticexperience, filename="StaticByExperience.pdf", width = 8, height = 8)

# Touch Rate by Age
touchrateate <- ggplot(d, aes(x = AgeYr, y = TouchRate))+ 
  xlab ("Age (Years)")+
  ylab ("Touch Rate")+
  geom_point()+
  geom_smooth(method=lm)+
  theme_bw(base_size = 18)
touchrateate
ggsave(touchrateate, filename="TouchRateByAge.png", width = 8, height = 8)

# Disc Rate by Age
discrateage <- ggplot(d, aes(x = AgeYr, y = DiscRate))+ 
  xlab ("Age (Years)")+
  ylab ("Discovery Rate")+
  geom_point()+
  geom_smooth(method=lm)+
  theme_bw(base_size = 18)
discrateage
ggsave(discrateage, filename="DiscRateByAge.png", width = 8, height = 8)


# Disc per touch by age
discpertouchage <- ggplot(d, aes(x = AgeYr, y = DiscPerTouch))+ 
  xlab ("Age (Years)")+
  ylab ("Discoveries Per Touch")+
  geom_point()+
  geom_smooth(method=lm)+
  theme_bw(base_size = 18)
discpertouchage
ggsave(discpertouchage, filename="DiscPerTouchByAge.png", width = 8, height = 8)

# Touch Rate by Experience
touchrateexp <- ggplot(d, aes(x = Experience, y = TouchRate))+ 
  xlab ("Experience")+
  ylab ("Touch Rate")+
  geom_point()+
  geom_smooth(method=lm)+
  theme_bw()
touchrateexp
ggsave(touchrateexp, filename="DiscRateByExp.pdf")

# Disc Rate by Experience
discrateexp <- ggplot(d, aes(x = Experience, y = DiscRate))+ 
  xlab ("Experience")+
  ylab ("Discovery Rate")+
  geom_point()+
  geom_smooth(method=lm)+
  theme_bw()
discrateexp
ggsave(discrateexp, filename="DiscRateByExp.pdf")

# Disc Per Touch by Experience 
discpertouchexp <- ggplot(d, aes(x = Experience, y = DiscPerTouch))+ 
  xlab ("Experience")+
  ylab ("Discoveries Per Touch")+
  geom_point()+
  geom_smooth(method=lm)+
  theme_bw()
discpertouchexp
ggsave(discpertouchexp, filename="DiscPerTouchByExp.pdf")


##Plotting residuals (but maybe makes more sense to plot pure size and then show results from glm with both age and total touches as predictors)
sizetotaltouchresidual <- ggplot(d, aes(x = AgeYr, y = PureSizeByTotalTouches.Residuals))+ 
  xlab ("Age (Years)")+
  ylab ("Size Controlled for By Total Touches (Residuals)")+
  geom_point()+
  geom_smooth(method=lm)+
  theme_bw(base_size = 18)
sizetotaltouchresidual
ggsave(sizetotaltouchresidual, filename="PureSizeByAgeResidualsTotalTouches.png", width = 8, height = 8)


sizeage <- ggplot(d, aes(x = AgeYr, y = Size))+ 
  xlab ("Age (Years)")+
  ylab ("Size of Compressed File")+
  geom_point()+
  geom_smooth(method=lm)+
  theme_bw(base_size = 18)
sizeage
ggsave(sizeage, filename="PureSizeByAge.png", width = 8, height = 8)