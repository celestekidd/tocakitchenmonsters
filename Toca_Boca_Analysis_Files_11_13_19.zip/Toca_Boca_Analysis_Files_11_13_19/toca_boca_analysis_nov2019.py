# Toca Boca Analyses - slightly revised Nov 2019

# with exporting individual files for zip and word net, added Dec 8 2014

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import date, datetime, time, timedelta
from itertools import groupby

# import things for zip analysis
import csv
import gzip
import csv
import os
import itertools

# reads in csv file of subject information
subjData = pd.read_csv('tocaboca_subjinfo.csv')

# inclusions
subjData = subjData[subjData.Include == 1]

# determines number of subjects via index of subject rows
numRows = len(subjData.index)

# generates the list of startLoc and endLoc times for each subject in the subjData file
startList = subjData.ix[:,'TimeStart']
endList = subjData.ix[:,'TimeEnd']

# make list of experience data
expList = subjData.ix[:, 'Experience']

# to start at first index in future loop
i = 0

# create dataframe to output summary information into
allinfo = pd.DataFrame(columns = ['SubjID','Objects'])

summaryData = pd.DataFrame(columns = ['SubjID','AgeMo','TotalTouches', 'UniqueTouches', 'StaticRatio', 'TimePlayed', 'TouchRate', 'DiscRate', 'Experience'])

# make new dataframe to hold just this subject's info for zipping and word netting
#justmyinfo = pd.DataFrame(columns = ['SubjID','Objects'])

#-----------------------------------------------------------------------------------------------
# loop through the subjects and get a usable piece of data from the gargantuan csv
# ----------------------------------------------------------------------------------------------
while i < numRows:
    
    # record some important info about each subject
    subjID = subjData.ix[i, 'SubjID']
    print subjID
    subjAge = subjData.ix[i, 'AgeMo']

    # use 'FileName' column in subject file to determine which csv file their data is in and open that file
    correctFile = subjData.ix[i, 'FileName']
    tbData = pd.read_csv("Data_Files/" + correctFile)
    
    # do some crazy things to get the start/end points in the right format to help trim the data
    # this particular subject's start and end value
    startTime = startList[i]
    endTime = endList[i]

    #experience for this participant
   
    tsExperience = expList[i]

    # find the location start and end of the participant's data and cut the dataframe to be only what we care about (+1 to the endCut so the last line is included)
    startCut = tbData.index.get_loc(startTime)
    endCut = tbData.index.get_loc(endTime)
    tbDataCut = tbData.ix[startCut:(endCut+1)]

    # clean up toca boca's lame header situation by resetting and renaming
    tbDataCut = tbDataCut.reset_index()
    tbDataCut.columns = ['time','event','object','scene','locationx','locationy']
 
    # get rid of rows of data that are touch move or touch end - because that's not the kid doing anything active with the screen
    getRidOfCrap = tbDataCut.applymap(lambda x: x in ['Touch move', 'Touch end', 'Scene Change'])
    tbDataCut = tbDataCut[-getRidOfCrap.event]
    tbDataCut = tbDataCut.reset_index()

#-------------------------------------------------------------------------------------------------------------
# now we have the right data for this subject, save some information about them
#-------------------------------------------------------------------------------------------------------------
        
    # calculates how long they played for (complicated bc there's crap on either side of the time and they are in a format where if the test occurs during the change of an hour it will throw everything off
    if float(startTime[11:13]) == float(endTime[11:13]):
        startTimeInSecs = (float(startTime[14:16])*60) + float(startTime[17:23])
        endTimeInSecs = (float(endTime[14:16])*60) + float(endTime[17:23])
    else:
        startTimeInSecs = (float(startTime[14:16])*60) + float(startTime[17:23])
        minutes = float(endTime[14:16]) + 60
        endTimeInSecs = (minutes*60) + float(endTime[17:23])

    timePlayed = endTimeInSecs - startTimeInSecs

#-----------------------------------------------------------------------------------------------------------------
# five minute cutoff - doesn't currently restrict it so that kids who didn't play for 5 minutes aren't included
#-----------------------------------------------------------------------------------------------------------------
    if timePlayed > 300:
        timePlayed = 300

        # makes a column with only the 00:00:00 time so we can figure out the 5 minute thing easier, 
        #and sets it as a datetime object so we can easily add 5 minutes to it 
        tbDataCut['shorttime'] = tbDataCut['time'].map(lambda x: x[11:19])
        tbDataCut['shorttime'] = tbDataCut['shorttime'].map(lambda x: datetime.strptime(x, '%H:%M:%S'))
        shorttimestart = tbDataCut.shorttime[0]
       
        # add five minutes to the time so we know what to search for
        shorttimeplusfive = shorttimestart + timedelta(minutes=5)

        # loop through the possible times to choose from and choose the row that has a time that 
        #is closest to the start time + five minutes, then crop the data again to the limit of 5 minutes (sorry for the weird naming)
        diffArray = pd.DataFrame(columns = ['Differences'])
        for x in tbDataCut['shorttime']:
            difference = abs(shorttimeplusfive - x)
            diffList = [{'Differences': difference}]
            diffArray = diffArray.append(diffList, ignore_index = True)
        
        fiveMinRow = tbDataCut.ix[diffArray.idxmin()]
        fiveMinRowInfo = diffArray.idxmin()
        fiveMinEnd = fiveMinRowInfo[0]
        tbDataCut = tbDataCut.ix[0:fiveMinEnd] 



#-------------------------------------------------------------------------------------------------------
# calculate some things
#-------------------------------------------------------------------------------------------------------

    # number of total touches
    numEvents = len(tbDataCut['event'])
    
    # number of ~unique~ objects they touched
    uniqueEvents = len(pd.unique(tbDataCut['object']))
    print timePlayed

    # counts the number of occurrences of each object in the set
    objCount = tbDataCut['object'].value_counts()


    # there is one subject who never starts or ends on static so this is just so the code doesn't break (and it's super
    # rare so I didn't take the time to build it in too flexibly)
    if subjID == 2199:
        staticRatio = 0
    else:
        staticRatio = (float(objCount['static'])/sum(objCount))
    # calculates touchRate
    touchRate = float(numEvents)/timePlayed

    # calculates rate of discovery of new objects
    discRate = float(uniqueEvents)/timePlayed

    # makes a list of all of the information we just calculated and appends it to the summary dataframe
    # added zipSize 11/9
    infoList = [{'SubjID': subjID,'AgeMo': subjAge,'TotalTouches': numEvents, 
                 'UniqueTouches': uniqueEvents, 'StaticRatio': staticRatio, 'TimePlayed': timePlayed,
                 'TouchRate': touchRate, 'DiscRate': discRate, 'Experience': tsExperience}]
    summaryData = summaryData.append(infoList, ignore_index = True)
    
    # print out a csv of ONLY that subjects info (for single case)
    justmyinfo = pd.DataFrame(columns = ['SubjID','Objects'])
    justmyinfo['Objects'] = tbDataCut['object']
    justmyinfo['SubjID'] = str(subjID)
 
    allinfo = allinfo.append(justmyinfo)
    justmyinfo.to_csv(str(subjID) +'.csv')
    
    # move on to the next subject
    i += 1


# get rid of rows where time played is less than 300 (five mins)
summaryData = summaryData[(summaryData.TimePlayed >= 300)]
summaryData = summaryData.reset_index()

# export summary data
# don't need to export summaryData to csv yet - need to do zip analysis and then combine into a single dataframe before exporting
summaryData.to_csv('TB_Summary.csv')
allinfo.to_csv('ObjectInfoList.csv')


#-------------------------------------------------------------------------------------------------------
# zip analysis combined from separate file
#-------------------------------------------------------------------------------------------------------

# define a function to create an array of different binary numbers - stole this from online, should find the link
def generate_binary(n, l):
    if n == 0:
       return l
    else:
        if len(l) == 0:
            return generate_binary(n-1, ["0", "1"])
        else:
            return generate_binary(n-1, [i + "0" for i in l] + [i + "1" for i in l])

# use big document to find all of the ID numbers and their corresponding object touches
#IDandObjects = open('Zip_and_Net/Tsimane_NEW_Aug_18/Tsimane_ObjectInfoList_Aug18.csv')
# open the one csv file that was just created - changed for dev sci submission
IDandObjects = open('ObjectInfoList.csv')
IDandObjects_csv = csv.reader(IDandObjects)

# lists to fill in: list of ID numbers to loop through when opening files, and a full list of objects
# so we can find the unique values and assign them a binary code
ID_list = []
allObjectList = []
sizeList = []

# using big file, fill in the above lists (IDs and objects)
for row in IDandObjects_csv:
    allObjectList.append(row[2])
    if row[0] == "0":
        ID_list.append(row[1])

# find list of unique objects and then make a list of binary codes so we can assign a 1:1 of object:binary
uniqueObjects = set(allObjectList)
binaryList = generate_binary(9, [])

# zip em up together into a cozy dictionary - this also chops off the extra binary codes
# so it doesn't matter that one list is longer, as long as it's the binary list so every item getes a code
binaryReference = zip(uniqueObjects, binaryList)

# not sure we need this, but here's the dictionary of how to translate from binary to object in case we ever care
binaryRef = open('binaryRef.csv', 'w')
writey = csv.writer(binaryRef)
writey.writerows(binaryReference)

# change the binary reference list to a dictionary so we can reference pieces of it more easily
binaryReference = dict(binaryReference)

# THE BIG MAGNIFICENT LOOP
# loop through IDs in list and open the file with the specified name
for ID in ID_list:
    objectList = []
    binaryObjects = []
    currentID = open('%s.csv' % ID)
    currentCSV = csv.reader(currentID)

# find object list for ONLY this ID (rather than earlier when we were looking across all IDs)
    for row in currentCSV:
        objectList.append(row[2])

# loop through the list of all of the objects (with repeats)
# search for the corresponding binary code in the dictionary, and append to new list
    for object in objectList:
        if object in binaryReference:
            binaryObjects.append(binaryReference[object])

# create the output file, titled by the ID number, containing the binary codes
# this is what we'll zip soon!
# you could do these next two lines if you want to make an intermediate csv but I don't see the point
#     outputFile = open('%s.csv' % ID, 'w')
#     writey = csv.writer(outputFile)
    binaryToZip = []
    for object in binaryObjects:
        binaryToZip.append(object)
# join the binary codes together to make one string that can be zipped
    smooshedToZip = "".join(binaryToZip)

# create gz zip files for the combined binary string
    f = gzip.open('%s.gz' % ID, 'wb')
    f.write(smooshedToZip)
    f.close()

# find size of the zipped file and append to a list of IDs and sizes
    file = ('%s.gz' % ID)
    statinfo = os.stat(file)
    size = statinfo.st_size
    sizeList.append(size)

zipSummary = pd.DataFrame({'Size': sizeList, 'SubjID': (map(float, ID_list))}, columns= ['SubjID', 'Size'])
# only want to export one file - combine the original and the one with zip analysis
zipSummary.to_csv('ZipSummaryFile.csv')

# merge the dataframes together to make a merged summary that includes the compression size information 
mergedSummary = pd.merge(left = summaryData, right = zipSummary, left_on = 'SubjID', right_on = 'SubjID')
mergedSummary.to_csv('mergedSummary.csv')


# make some plots
# -----------------------------------------------------------------------------------
# plot age vs. number of unique touches
plt.subplot(2,3,1)
plt.scatter(summaryData.AgeMo, summaryData.UniqueTouches)
plt.xlabel('Age in Months')
plt.ylabel('Unique Objects Found')

# plot age vs. percentage of static touches
plt.subplot(2,3,2)
plt.scatter(summaryData.AgeMo, summaryData.StaticRatio)
plt.xlabel('Age in Months')
plt.ylabel('Percent Static Touches')

# plot age vs. rate of touches
plt.subplot(2,3,3)
plt.scatter(summaryData.AgeMo, summaryData.TouchRate)
plt.xlabel('Age in Months')
plt.ylabel('Touch Rate')

# plot age vs. rate of novel object discovery
plt.subplot(2,3,4)
plt.scatter(summaryData.AgeMo, summaryData.DiscRate)
plt.xlabel('Age in Months')
plt.ylabel('Rate of Discovery')


# # plot stickymean
# plt.subplot(2,3,5)
# plt.scatter(summaryData.AgeMo, summaryData.StickyMean)
# plt.xlabel('Age in Months')
# plt.ylabel('Stickiness')
plt.show()
#


